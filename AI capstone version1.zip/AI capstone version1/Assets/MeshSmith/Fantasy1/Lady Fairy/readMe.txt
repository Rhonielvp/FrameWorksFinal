Fantasy Monster 1 Series
Lady Fairy has 16 animations and 3 colors,low poly and very good performance on mobiles.

Triangles: 
Lady Fairy 2926 Tris

Motions
Idle
Show
Atk01
Atk02
Atk03
Atk04
Atk05
Atk06
Atk07
Atk08
Hurt
Special_21
Stun
Sleep
Victory
Walk

Textures
102810_xjl_npc_d_512.png 512x512
102820_xjl_npc_d_512.png 512x512
102830_xjl_npc_d_512.png 512x512

Thanks and do not forget to rate.
Please remember to rate our packages, we will bring more quality models soon.
We hope you will like our models.
Enjoy. 

Video was made with bloom effect and Demo scene was made from Medieval Cartoon Village.